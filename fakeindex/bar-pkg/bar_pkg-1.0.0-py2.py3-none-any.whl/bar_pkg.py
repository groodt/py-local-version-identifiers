def bar():
    "bar"
